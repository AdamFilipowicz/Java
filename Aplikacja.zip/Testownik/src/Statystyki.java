
import java.util.List;

/**
 *
 * @author Adam Filipowicz
 */
public class Statystyki {
    private int[] zdobytePunkty;
    private ZestawKartOdpowiedzi zestawAnalizowany;
    private List<KartaOdpowiedzi> zestawKart;
    
    private KartaOdpowiedzi klucz;
    
    
    public Statystyki(ZestawKartOdpowiedzi zestawAnalizowany){
        KartaOdpowiedzi aktualnaKarta;
        this.zestawAnalizowany = zestawAnalizowany;
        zestawKart = zestawAnalizowany.getZestawKart();
        klucz = zestawKart.get(0);
        zdobytePunkty = new int[zestawAnalizowany.getLiczbaKart()-1];
        int[] odpowiedziKlucza;
        int[] odpowiedziAktualnejKarty;
        if(klucz!=null){
            odpowiedziKlucza=klucz.getOdpowiedzi();
            for(int i=1;i<zestawAnalizowany.getLiczbaKart();i++){
                aktualnaKarta=zestawKart.get(i);
                odpowiedziAktualnejKarty=aktualnaKarta.getOdpowiedzi();
                for(int j=0;j<zestawAnalizowany.getLiczbaPytan();j++){
                    if(odpowiedziKlucza[j]==odpowiedziAktualnejKarty[j])
                        zdobytePunkty[i-1]++;
                }
            }
        }
    }
    
    public String Histogram(){
        return "Dziala";
    }
}
