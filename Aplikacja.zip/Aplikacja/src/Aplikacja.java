import java.io.FileInputStream;
import java.io.ObjectInputStream;
/**
 *
 * @author Adam Filipowicz
 */
public class Aplikacja {

    private UserDialog UI = new ConsoleUserDialog();
    
    private static final String MENU_APLIKACJA = 
			"M E N U   G L O W N E \n" +
			"1 - Ustaw liczbe pytan i opcji \n" +
			"2 - Wczytaj klucz odpowiedzi        \n" +
			"3 - Wczytaj karte odpowiedzi  \n" +
			"4 - Sprawdz statystyki testu     \n" + 
                        "0 - Zakoncz program          \n"; 
    
    private static int[] odpowiedziPoprawne;
    
    private static int liczbaPytan;
    private static int liczbaOpcji;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new Aplikacja();
        odpowiedziPoprawne=new int[liczbaPytan];
        odpowiedziPoprawne[0]=2;
        odpowiedziPoprawne[1]=3;
        odpowiedziPoprawne[2]=2;
        odpowiedziPoprawne[3]=1;
        odpowiedziPoprawne[4]=2;
        odpowiedziPoprawne[5]=3;
        odpowiedziPoprawne[6]=2;
        ZestawKartOdpowiedzi zestaw=new ZestawKartOdpowiedzi(liczbaPytan,liczbaOpcji,odpowiedziPoprawne);
        KartaOdpowiedzi karta=new KartaOdpowiedzi(liczbaPytan,liczbaOpcji);
        karta.setOdpowiedzi(odpowiedziPoprawne);
        zestaw.dodajKarte(karta);
        Statystyki stat=new Statystyki(zestaw);
        System.out.println(stat.Histogram());
    }
    
    public Aplikacja(){
        liczbaPytan=0;
        liczbaOpcji=0;
        while (true) {
            try {
                switch (UI.enterInt(MENU_APLIKACJA + "==>> ")) {
                case 1:
                        ustaw();
                        break;
                case 2:
                        wczytajKlucz();
                        break;
                case 3:
                        wczytajKarte();
                        break;
                case 4:
                        sprawdzStatystyki();
                        break;
                case 0:
                        UI.printInfoMessage("\nProgram zakonczyl dzialanie!");
                        System.exit(0);
                }
            } 
            catch (Exception e) {
                    UI.printErrorMessage(e.getMessage());
            }
        }
    }
    
    public void ustaw(){
        liczbaPytan=UI.enterInt("Podaj liczbe pytan testu: ");
        liczbaOpcji=UI.enterInt("Podaj liczbe opcji testu: ");
    }
    
    public void wczytajKlucz(){
        if(liczbaPytan==0 || liczbaOpcji==0){
            UI.printErrorMessage("Podaj najpierw liczbe pytan i opcji");
            return;
        }
        String sciezka = UI.enterString("Podaj sciezke do klucza odpowiedzi: ");
        try{
            wczytajZPliku(sciezka);
        }
        catch(Exception e){
            UI.printErrorMessage(e.getMessage());
        }
        for(int i=0;i<liczbaPytan;i++){
            System.out.println(odpowiedziPoprawne[i]);
        }
    }
    
    public void wczytajKarte(){
        if(liczbaPytan==0 || liczbaOpcji==0){
            UI.printErrorMessage("Podaj najpierw liczbe pytan i opcji");
            return;
        }
    }
    
    public void sprawdzStatystyki(){
        if(liczbaPytan==0 || liczbaOpcji==0){
            UI.printErrorMessage("Podaj najpierw liczbe pytan i opcji");
            return;
        }
    }
    
    public void wczytajZPliku(String fileName) throws Exception {
        ObjectInputStream in = new ObjectInputStream(new FileInputStream(fileName));
        for(int i=0;i<liczbaPytan;i++){
            odpowiedziPoprawne[i] = (int)in.readObject();
        }
        in.close();
    }
    
}
